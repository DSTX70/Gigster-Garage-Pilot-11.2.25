# Gigster Garage — Replit One Drop (2025-10-05)

**How to use**
1) Upload this ZIP to your Replit project root and extract it.
2) Confirm folders exist: /docs, /public, /config/flags, /src/components, /src/lib, /ops/pm
3) Visit /pricing to view the PricingTable. Use the runtime flags below on staging.

**Runtime flags (browser console)**
```js
window.__GG_FLAGS = {
  "feature.analytics_insights": false,
  "feature.automation_power": false
}; location.reload();
```

**Verify**
Run `verify_staging.sh` to collect logs and a tarball:
```bash
chmod +x verify_staging.sh
STAGING_DOMAIN="your-staging.example.com" ./verify_staging.sh
```
Evidence bundle: `/tmp/gg_verify/staging_verification_evidence.tgz`
