import React from "react";
import StatusBadge from "../src/StatusBadge";
import "../src/styles.css";

export default function App(){
  return (
    <div style={{display:'grid', gap:12, padding:16}}>
      <StatusBadge status="critical" />
      <StatusBadge status="high" />
      <StatusBadge status="medium" />
      <StatusBadge status="low" />
      <StatusBadge status="complete" />
      <StatusBadge status="pending" />
      <StatusBadge status="overdue" />
    </div>
  );
}
