# VSuite HQ — Status Badge Icon Set (Replit Handoff)

This bundle gives your devs everything needed to drop a **professional status badge system** into the app.

## What's included
- `tokens/status-badges.json` — design tokens (names, icon mapping, colors, usage notes)
- `src/StatusBadge.tsx` — reusable React component using **lucide-react** icons
- `src/statusMap.ts` — central mapping for status → icon/color/titles
- `src/styles.css` — CSS variables and minimal styles (works with or without Tailwind)
- `examples/App.tsx` — minimal demo of all badges

## Install (Replit / Node)
```bash
npm i lucide-react clsx
# or
pnpm add lucide-react clsx
```
If you're using Tailwind, keep it. If not, `src/styles.css` includes CSS vars you can import.

## Usage
```tsx
import { StatusBadge } from "./src/StatusBadge";

<StatusBadge status="critical" />
<StatusBadge status="overdue" label="Overdue" />
```

## Design Notes
- **Overdue** uses an octagon with **yellow/red diagonal stripes** to distinguish it from **Critical** (red octagon with `!`).
- **Pending** is a **light gray circle** outline.
- Colors are exported as CSS variables; adjust in `styles.css` or wire to your theme.
