# Gigster Garage — TypeScript Client

Minimal fetch wrappers for the **Combined OpenAPI**.

## Install
Copy `index.ts` into your project or publish the folder as a private package.

## Use
```ts
import { createClient } from "./index";
const client = createClient({ baseUrl: "http://localhost:8000" });

// examples
await client.getApiPacks();
await client.postApiPacks({ body: { name: "Local Lift", summary: "Pack", price: 499 } });
```
