# Publishing @gigster-garage/api-client

1) Add `NPM_TOKEN` in GitHub repo → Settings → Secrets and variables → Actions.
2) Protect `main` branch, require CI.
3) Release:
```bash
npm version patch   # or minor / major
git push --follow-tags
```
