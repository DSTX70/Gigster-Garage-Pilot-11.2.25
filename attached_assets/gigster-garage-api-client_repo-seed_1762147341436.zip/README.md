# @gigster-garage/api-client

Minimal TypeScript client for the Gigster Garage Combined API.

## Install & Build
```bash
npm i
npm run build
```

## Test
```bash
npm run test
```

## Publish
Tag with semantic version (vX.Y.Z) and push; the release workflow will build, test, attach artifacts, and publish to npm with provenance.
