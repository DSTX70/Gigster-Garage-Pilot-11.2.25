---
name: Feature request
about: Suggest an idea for this project
title: "feat: <short summary>"
labels: ["enhancement"]
assignees: []
---

## Summary
What you want to happen.

## Motivation / Use case
Why this is valuable.

## Proposed API / Changes
- New/changed methods and parameters
- Example usage

## Acceptance Criteria
- [ ] Tests added/updated
- [ ] Docs updated
- [ ] No breaking changes (or note them below)

## Additional context
Links, screenshots, or notes.
