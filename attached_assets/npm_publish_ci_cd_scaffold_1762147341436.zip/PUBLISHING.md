# Publishing @gigster-garage/api-client

## One-time setup
1. In GitHub repo settings → **Secrets and variables → Actions**, add:
   - `NPM_TOKEN` (npm automation token with 2FA _required for publish only_)
2. Ensure `package.json` has `"publishConfig.access": "restricted"` and scope `@gigster-garage`.
3. Protect `main` branch and require CI passing checks.

## Release
- Bump version and create a tag:
```bash
npm version patch   # or minor / major
git push --follow-tags
```
- The `release` workflow will:
  - run tests, build, docs
  - create a GitHub Release with artifacts
  - publish to npm with provenance

## Install
```bash
npm i @gigster-garage/api-client
```
