# @gigster-garage/api-client

Minimal TypeScript client for the Gigster Garage Combined API.

## Install & Build
```bash
npm i
npm run build
```

## Test
```bash
npm run test
```

## Docs
```bash
npm run docs
```

## Publish
Tag with semantic version (vX.Y.Z) and push; release workflow builds/tests/attaches artifacts and publishes to npm with provenance.
