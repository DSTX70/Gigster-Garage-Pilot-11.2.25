# Publishing @gigster-garage/api-client

1) Add `NPM_TOKEN` in GitHub repo → Settings → Secrets and variables → Actions.
2) Enable Pages: Settings → Pages → Source = GitHub Actions.
3) Protect `main` branch, require CI.
4) Release:
```bash
npm version patch   # or minor / major
git push --follow-tags
```
