# Contributing to @gigster-garage/api-client

Thanks for helping improve the Gigster Garage API client!

## Getting started
```bash
npm i
npm run build
npm run test
```

## Branch & PR
- Branch from `main`
- Keep PRs focused and small
- Use the PR template and ensure CI passes

## Conventional commits
Use these prefixes in your commit messages and PR titles:
- `feat:` new feature
- `fix:` bug fix
- `docs:` documentation
- `refactor:` code refactor
- `perf:` performance
- `test:` tests
- `chore:` build/deps/tooling

Examples:
- `feat: add Importer commit wrapper`
- `fix: handle 4xx error bodies in doFetch`
- `docs: clarify baseUrl usage`

These power **release-please** to generate version bumps and CHANGELOG entries.

## Tests
- Write unit tests in `test/` using **Vitest**
- Mock `fetch` for client calls (see existing specs)

## Releases
- Merging to `main` with conventional commits will open a **Release PR** (release-please)
- Merge the Release PR to tag `vX.Y.Z`
- The **release** workflow will build, attach artifacts, publish to npm (provenance), and trigger docs Pages deploy

## Docs
- `npm run docs` generates Typedoc to `/docs`
- Docs are published to GitHub Pages on release

## Security
- **CodeQL** runs on PRs and main
- Please avoid committing secrets; use GitHub Actions secrets

## Dual registry (optional)
- npmjs: default publish via `release.yml`
- GitHub Packages: optional `release-gh-packages.yml` publishes on tag
