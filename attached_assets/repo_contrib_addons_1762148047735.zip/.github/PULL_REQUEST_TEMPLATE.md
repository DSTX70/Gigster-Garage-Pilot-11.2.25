## Summary
_What does this PR change?_

## Type of change
- [ ] feat (new feature)
- [ ] fix (bug fix)
- [ ] docs (documentation only)
- [ ] refactor (no functional change)
- [ ] perf (performance)
- [ ] test (adds or fixes tests)
- [ ] chore (build, deps, tooling)

## Checklist
- [ ] Conventional commit in PR title (e.g., `feat: add Packsmith blueprint client`)
- [ ] Unit tests pass (`npm run test`)
- [ ] Build passes (`npm run build`)
- [ ] Types OK (d.ts generated)
- [ ] Updated docs if needed (`npm run docs`)

## Screenshots / Logs (optional)

## Breaking changes
_List any breaking changes and migration notes_
