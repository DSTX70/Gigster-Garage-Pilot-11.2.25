// Auto-generated minimal client from combined OpenAPI (L0/L1-safe)
// Usage:
//   const client = createClient({ baseUrl: 'http://localhost:8000' });
//   await client.postApiPacks({ body: {...} });
export type ClientConfig = { baseUrl: string; headers?: Record<string,string>; fetchImpl?: typeof fetch };
export type RequestOpts = { params?: Record<string,string|number|boolean|undefined>; body?: any; headers?: Record<string,string> };

export function createClient(cfg: ClientConfig) {
  const doFetch = async (method: string, path: string, opts: RequestOpts = {}) => {
    let url = cfg.baseUrl.replace(/\/$/,'') + path;
    // Sub path params {id}
    if (opts.params) {
      for (const [k,v] of Object.entries(opts.params)) {
        url = url.replace(new RegExp(`{${k}}`,'g'), encodeURIComponent(String(v ?? '')));
      }
    }
    const headers = { 'content-type': 'application/json', ...(cfg.headers||{}), ...(opts.headers||{}) };
    const res = await (cfg.fetchImpl || fetch)(url, {
      method, headers,
      body: ['POST','PUT','PATCH'].includes(method) ? JSON.stringify(opts.body ?? {}) : undefined,
    });
    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`${method} ${path} -> ${res.status}: ${txt}`);
    }
    const ct = res.headers.get('content-type')||'';
    return ct.includes('application/json') ? res.json() : res.text();
  };

  async function getApiPacks(opts?: RequestOpts) {
    return doFetch('GET', '/api/packs', opts);
  }

  async function postApiPacks(opts?: RequestOpts) {
    return doFetch('POST', '/api/packs', opts);
  }

  async function getApiPacksPackid(opts?: RequestOpts) {
    return doFetch('GET', '/api/packs/{packId}', opts);
  }

  async function patchApiPacksPackid(opts?: RequestOpts) {
    return doFetch('PATCH', '/api/packs/{packId}', opts);
  }

  async function postApiPacksPackidBlueprint(opts?: RequestOpts) {
    return doFetch('POST', '/api/packs/{packId}/blueprint', opts);
  }

  async function getApiPacksPackidBlueprint(opts?: RequestOpts) {
    return doFetch('GET', '/api/packs/{packId}/blueprint', opts);
  }

  async function postApiPacksPackidSeed(opts?: RequestOpts) {
    return doFetch('POST', '/api/packs/{packId}/seed', opts);
  }

  async function postApiImportSessions(opts?: RequestOpts) {
    return doFetch('POST', '/api/import/sessions', opts);
  }

  async function getApiImportSessionsSessionid(opts?: RequestOpts) {
    return doFetch('GET', '/api/import/sessions/{sessionId}', opts);
  }

  async function deleteApiImportSessionsSessionid(opts?: RequestOpts) {
    return doFetch('DELETE', '/api/import/sessions/{sessionId}', opts);
  }

  async function postApiImportSessionsSessionidUpload(opts?: RequestOpts) {
    return doFetch('POST', '/api/import/sessions/{sessionId}/upload', opts);
  }

  async function postApiImportSessionsSessionidMap(opts?: RequestOpts) {
    return doFetch('POST', '/api/import/sessions/{sessionId}/map', opts);
  }

  async function postApiImportSessionsSessionidValidate(opts?: RequestOpts) {
    return doFetch('POST', '/api/import/sessions/{sessionId}/validate', opts);
  }

  async function postApiImportSessionsSessionidStage(opts?: RequestOpts) {
    return doFetch('POST', '/api/import/sessions/{sessionId}/stage', opts);
  }

  async function postApiImportSessionsSessionidCommit(opts?: RequestOpts) {
    return doFetch('POST', '/api/import/sessions/{sessionId}/commit', opts);
  }

  async function getApiIcadenceChannels(opts?: RequestOpts) {
    return doFetch('GET', '/api/icadence/channels', opts);
  }

  async function postApiIcadenceChannels(opts?: RequestOpts) {
    return doFetch('POST', '/api/icadence/channels', opts);
  }

  async function getApiIcadenceChannelsChannelid(opts?: RequestOpts) {
    return doFetch('GET', '/api/icadence/channels/{channelId}', opts);
  }

  async function putApiIcadenceChannelsChannelidUtms(opts?: RequestOpts) {
    return doFetch('PUT', '/api/icadence/channels/{channelId}/utms', opts);
  }

  async function postApiIcadenceChannelsChannelidTestPost(opts?: RequestOpts) {
    return doFetch('POST', '/api/icadence/channels/{channelId}/test-post', opts);
  }

  async function postApiIcadenceSpend(opts?: RequestOpts) {
    return doFetch('POST', '/api/icadence/spend', opts);
  }

  return {
    deleteApiImportSessionsSessionid,
    getApiIcadenceChannels,
    getApiIcadenceChannelsChannelid,
    getApiImportSessionsSessionid,
    getApiPacks,
    getApiPacksPackid,
    getApiPacksPackidBlueprint,
    patchApiPacksPackid,
    postApiIcadenceChannels,
    postApiIcadenceChannelsChannelidTestPost,
    postApiIcadenceSpend,
    postApiImportSessions,
    postApiImportSessionsSessionidCommit,
    postApiImportSessionsSessionidMap,
    postApiImportSessionsSessionidStage,
    postApiImportSessionsSessionidUpload,
    postApiImportSessionsSessionidValidate,
    postApiPacks,
    postApiPacksPackidBlueprint,
    postApiPacksPackidSeed,
    putApiIcadenceChannelsChannelidUtms
  };
}