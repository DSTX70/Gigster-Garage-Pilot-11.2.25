# Publishing @gigster-garage/api-client

- Add `NPM_TOKEN` in GitHub repo → Settings → Secrets → Actions.
- Enable Pages: Settings → Pages → Source = GitHub Actions.
- Protect `main` branch.
- Release:
```bash
npm version patch   # or minor / major
git push --follow-tags
```
