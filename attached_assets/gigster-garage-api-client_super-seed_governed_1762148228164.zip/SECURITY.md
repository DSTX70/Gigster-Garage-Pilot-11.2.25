# Security Policy

## Supported Versions
We support the latest minor versions for security updates. Please keep your dependency up to date.

## Reporting a Vulnerability
- Do **not** open a public issue for security vulnerabilities.
- Use the GitHub **Security → Report a vulnerability** workflow on this repository.
- Include reproduction details and version info.
- We will acknowledge receipt within 3 business days.

## Disclosure
We follow responsible disclosure. Once a fix is available and users have reasonable time to upgrade, we may publish details in the CHANGELOG.
