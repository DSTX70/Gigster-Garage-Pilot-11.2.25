# Contributing to @gigster-garage/api-client

Thanks for helping improve the Gigster Garage API client!

## Getting started
```bash
npm i
npm run build
npm run test
```

## Branch & PR
- Branch from `main`
- Keep PRs focused and small
- Use the PR template and ensure CI passes

## Conventional commits
Use these prefixes:
`feat:`, `fix:`, `docs:`, `refactor:`, `perf:`, `test:`, `chore:`

## Tests
- Write unit tests in `test/` using Vitest
- Mock `fetch` for client calls (see existing specs)

## Releases
- release-please opens a Release PR from conventional commits
- Merging the Release PR tags `vX.Y.Z`
- `release` workflow then builds/artifacts/publishes to npm (provenance) and triggers docs Pages

## Docs
- `npm run docs` generates Typedoc to `/docs` (published on release)

## Security
- CodeQL runs on PRs and `main`
- Use GitHub Actions secrets; avoid committing secrets
