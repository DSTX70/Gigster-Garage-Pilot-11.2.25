import { describe, it, expect, vi, beforeEach } from "vitest";
import { createClient } from "../src/index";
describe("Packsmith", () => {
  beforeEach(() => {
    // @ts-ignore
    global.fetch = vi.fn(async (url: string, init: any) => {
      if (url.includes("/api/packs/123/blueprint") && init?.method === "POST") {
        return new Response(JSON.stringify({ packId: "123" }), { status: 200, headers: { "content-type": "application/json" } });
      }
      if (url.includes("/api/packs/123/seed") && init?.method === "POST") {
        return new Response(JSON.stringify({ createdTasks: 7 }), { status: 201, headers: { "content-type": "application/json" } });
      }
      return new Response("Not Found", { status: 404 });
    });
  });
  it("blueprint + seed", async () => {
    const client = createClient({ baseUrl: "http://localhost:8000" });
    const bp = await client.postApiPacksByPackIdBlueprint({ params: { packId: "123" } });
    expect(bp.packId).toBe("123");
    const seed = await client.postApiPacksByPackIdSeed({ params: { packId: "123" } });
    expect(seed.createdTasks).toBe(7);
  });
});