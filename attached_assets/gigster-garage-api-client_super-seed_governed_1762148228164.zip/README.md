# @gigster-garage/api-client

TypeScript client for the Gigster Garage Combined API.

## Install & Build
```bash
npm i
npm run build
```

## Test
```bash
npm run test
```

## Docs
```bash
npm run docs
```

## Publish (npm, with provenance)
Tag `vX.Y.Z` and push — the release workflow builds/tests/attaches artifacts and publishes to npm.
