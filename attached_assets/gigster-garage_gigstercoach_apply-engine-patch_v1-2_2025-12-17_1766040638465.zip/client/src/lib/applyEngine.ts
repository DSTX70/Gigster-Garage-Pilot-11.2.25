import type { ApplyPayload, ApplyTarget } from "../../../shared/contracts/applyEngine";

/**
 * Pure string operation; safe and deterministic.
 * NOTE: The server still validates + records; client mutation happens only after explicit user click.
 */
export function applyToString(existing: string, payload: ApplyPayload): string {
  const current = existing ?? "";
  const value = payload.value ?? "";
  switch (payload.action) {
    case "append":
      return current.length ? current + "\n\n" + value : value;
    case "prepend":
      return current.length ? value + "\n\n" + current : value;
    case "replace":
      return value;
    default: {
      // Exhaustive check
      const _never: never = payload.action;
      return current;
    }
  }
}

/**
 * Returns true if we should show a confirm dialog before applying.
 * Policy: replace is always confirm if it would overwrite non-empty content with a different value.
 */
export function requiresConfirm(existing: string, payload: ApplyPayload): boolean {
  if (payload.action !== "replace") return false;
  const current = (existing ?? "").trim();
  const next = (payload.value ?? "").trim();
  return current.length > 0 && current !== next;
}

/**
 * Apply payload to a local "draft" object. Caller owns state updates.
 *
 * draft shape expectation (minimal):
 * - { invoice?: { terms?: string } }
 * - { proposal?: { terms?: string } }
 * - { message?: { body?: string } }
 */
export function applyToDraft<T extends Record<string, any>>(draft: T, payload: ApplyPayload): T {
  const clone: any = structuredClone ? structuredClone(draft) : JSON.parse(JSON.stringify(draft));
  const target: ApplyTarget = payload.target;

  if (target === "invoice.terms") {
    clone.invoice = clone.invoice ?? {};
    clone.invoice.terms = applyToString(clone.invoice.terms ?? "", payload);
    return clone;
  }

  if (target === "proposal.terms") {
    clone.proposal = clone.proposal ?? {};
    clone.proposal.terms = applyToString(clone.proposal.terms ?? "", payload);
    return clone;
  }

  if (target === "message.body") {
    clone.message = clone.message ?? {};
    clone.message.body = applyToString(clone.message.body ?? "", payload);
    return clone;
  }

  // Should be unreachable due to contract typing, but keep runtime safety.
  return clone;
}
