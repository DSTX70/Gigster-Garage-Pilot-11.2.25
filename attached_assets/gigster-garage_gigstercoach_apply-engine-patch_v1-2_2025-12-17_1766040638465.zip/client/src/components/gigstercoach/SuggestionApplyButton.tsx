import React from "react";
import type { ApplyPayload } from "../../../shared/contracts/applyEngine";
import { applyToDraft, requiresConfirm } from "../../lib/applyEngine";

/**
 * SuggestionApplyButton
 * - Calls server to validate + record the apply event.
 * - Mutates local draft only after server OK.
 *
 * Integration note:
 * - Replace `applyEndpoint` with your actual route if different.
 * - Pass `draft` + `setDraft` from the in-flow composer/editor context.
 */
export function SuggestionApplyButton(props: {
  suggestionId: string;
  payload: ApplyPayload;
  draft: any;
  setDraft: (next: any) => void;
  onApplied?: () => void;
  disabled?: boolean;
  applyEndpoint?: (suggestionId: string) => string;
}) {
  const {
    suggestionId,
    payload,
    draft,
    setDraft,
    onApplied,
    disabled,
    applyEndpoint = (id) => `/api/gigstercoach/suggestions/${id}/apply`,
  } = props;

  const [busy, setBusy] = React.useState(false);
  const [err, setErr] = React.useState<string | null>(null);

  const onClick = async () => {
    setErr(null);

    const existing =
      payload.target === "invoice.terms"
        ? draft?.invoice?.terms ?? ""
        : payload.target === "proposal.terms"
          ? draft?.proposal?.terms ?? ""
          : draft?.message?.body ?? "";

    if (requiresConfirm(existing, payload)) {
      const ok = window.confirm("This will replace existing text. Apply anyway?");
      if (!ok) return;
    }

    setBusy(true);
    try {
      const res = await fetch(applyEndpoint(suggestionId), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ payload }),
      });

      if (!res.ok) {
        const txt = await res.text().catch(() => "");
        throw new Error(txt || `Apply failed (${res.status})`);
      }

      // Only after server validation passes, mutate the local draft.
      const nextDraft = applyToDraft(draft, payload);
      setDraft(nextDraft);
      onApplied?.();
    } catch (e: any) {
      setErr(e?.message ?? "Apply failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <button
        type="button"
        onClick={onClick}
        disabled={disabled || busy}
        style={{
          padding: "8px 12px",
          borderRadius: 10,
          border: "1px solid rgba(0,0,0,0.12)",
          cursor: disabled || busy ? "not-allowed" : "pointer",
        }}
      >
        {busy ? "Applying…" : "Apply"}
      </button>
      {err ? <div style={{ color: "crimson", fontSize: 12 }}>{err}</div> : null}
    </div>
  );
}
