-- GigsterCoach Apply Engine v1.2 (2025-12-17)
-- Adds typed apply payload + apply event trail.
-- NOTE: Adjust table names if your schema differs.

BEGIN;

-- Suggestions table: add apply_payload + applied fields
ALTER TABLE IF EXISTS gigstercoach_suggestions
  ADD COLUMN IF NOT EXISTS apply_payload JSONB;

ALTER TABLE IF EXISTS gigstercoach_suggestions
  ADD COLUMN IF NOT EXISTS applied_at TIMESTAMPTZ;

ALTER TABLE IF EXISTS gigstercoach_suggestions
  ADD COLUMN IF NOT EXISTS applied_by TEXT;

-- Optional: event table for audit-grade trace
CREATE TABLE IF NOT EXISTS gigstercoach_apply_events (
  id BIGSERIAL PRIMARY KEY,
  suggestion_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  payload JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMIT;
