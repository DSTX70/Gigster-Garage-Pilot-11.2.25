/**
 * Stable JSON stringify for equality checks.
 * Ensures payload equality comparison is deterministic.
 */
export function stableStringify(value: any): string {
  return JSON.stringify(sortKeys(value));
}

function sortKeys(x: any): any {
  if (Array.isArray(x)) return x.map(sortKeys);
  if (x && typeof x === "object") {
    const out: any = {};
    Object.keys(x)
      .sort()
      .forEach((k) => {
        out[k] = sortKeys(x[k]);
      });
    return out;
  }
  return x;
}
