import { APPLY_ACTIONS, APPLY_TARGETS } from "../../../shared/contracts/applyEngine";

export function isWhitelistedTarget(target: string): boolean {
  return (APPLY_TARGETS as readonly string[]).includes(target);
}

export function isWhitelistedAction(action: string): boolean {
  return (APPLY_ACTIONS as readonly string[]).includes(action);
}
