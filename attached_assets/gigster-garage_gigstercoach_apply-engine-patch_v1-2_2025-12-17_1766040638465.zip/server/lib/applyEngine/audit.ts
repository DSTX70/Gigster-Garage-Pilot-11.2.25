/**
 * Best-effort audit emitter for Apply Engine events.
 * If you already have an audit logger, wire it in here.
 */
export type ApplyAuditEvent = {
  event: "gigstercoach.apply";
  suggestionId: string;
  userId: string;
  target: string;
  action: string;
  createdAt: string; // ISO
};

export async function emitApplyAudit(evt: ApplyAuditEvent): Promise<void> {
  try {
    // TODO: Replace with your canonical audit pipeline if present.
    // Example:
    // await audit.emit(evt);
    console.log("[AUDIT]", JSON.stringify(evt));
  } catch {
    // swallow
  }
}
