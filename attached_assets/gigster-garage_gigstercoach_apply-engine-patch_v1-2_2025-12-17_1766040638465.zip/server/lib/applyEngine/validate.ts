import type { ApplyPayload } from "../../../shared/contracts/applyEngine";
import { APPLY_ENGINE_VERSION } from "../../../shared/contracts/applyEngine";
import { isWhitelistedAction, isWhitelistedTarget } from "./whitelist";

const MAX_VALUE_CHARS = 8000;

export function validateApplyPayload(payload: any): { ok: true; payload: ApplyPayload } | { ok: false; error: string } {
  if (!payload || typeof payload !== "object") return { ok: false, error: "Missing payload" };
  if (payload.v !== APPLY_ENGINE_VERSION) return { ok: false, error: "Unsupported payload version" };

  const target = payload.target;
  const action = payload.action;
  const value = payload.value;

  if (typeof target !== "string" || !isWhitelistedTarget(target)) return { ok: false, error: "Target not allowed" };
  if (typeof action !== "string" || !isWhitelistedAction(action)) return { ok: false, error: "Action not allowed" };
  if (typeof value !== "string") return { ok: false, error: "Value must be a string" };
  if (value.length === 0) return { ok: false, error: "Value cannot be empty" };
  if (value.length > MAX_VALUE_CHARS) return { ok: false, error: "Value too long" };

  // Basic plain-text guard: block obvious HTML tags (keep it simple; you can tighten later).
  if (/<\s*script\b/i.test(value)) return { ok: false, error: "Disallowed content" };

  return { ok: true, payload: payload as ApplyPayload };
}
