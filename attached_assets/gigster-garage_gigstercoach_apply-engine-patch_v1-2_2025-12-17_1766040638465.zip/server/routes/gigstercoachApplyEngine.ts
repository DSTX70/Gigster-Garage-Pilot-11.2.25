import type { Express, Request, Response } from "express";
import type { ApplyRequestBody, ApplyPayload } from "../../shared/contracts/applyEngine";
import { stableStringify } from "../lib/applyEngine/stableJson";
import { validateApplyPayload } from "../lib/applyEngine/validate";
import { emitApplyAudit } from "../lib/applyEngine/audit";

/**
 * GigsterCoach Apply Engine routes (v1.2)
 *
 * Design goals:
 * - Typed payloads imported from shared/contracts
 * - Server validates payload shape, whitelist, and deep-equality vs stored suggestion payload
 * - Server records applied (and emits best-effort audit)
 * - Client mutates local state only after explicit click + server OK
 *
 * Integration dependencies:
 * - You must provide `requireAuth` and `requirePlan` middlewares from your existing routes.ts
 * - You must provide `db` access methods (see TODOs below)
 */
export function registerGigstercoachApplyEngine(
  app: Express,
  deps: {
    requireAuth: any;
    requirePlan: any;
    /**
     * Minimal DB hooks (implement using your existing db layer).
     */
    getSuggestionById: (id: string) => Promise<{
      id: string;
      userId: string;
      status: string;
      applyPayload: ApplyPayload | null;
    } | null>;
    markSuggestionApplied: (args: { id: string; userId: string; payload: ApplyPayload }) => Promise<{ appliedAt: string }>;
    insertApplyEvent?: (args: { suggestionId: string; userId: string; payload: ApplyPayload }) => Promise<void>;
  }
) {
  const { requireAuth, requirePlan, getSuggestionById, markSuggestionApplied, insertApplyEvent } = deps;

  app.post(
    "/api/gigstercoach/suggestions/:id/apply",
    requireAuth,
    requirePlan,
    async (req: Request, res: Response) => {
      const suggestionId = String(req.params.id || "");
      const body = (req.body || {}) as ApplyRequestBody;

      const validated = validateApplyPayload(body.payload);
      if (!validated.ok) return res.status(400).json({ message: validated.error });

      const payload = validated.payload;

      const suggestion = await getSuggestionById(suggestionId);
      if (!suggestion) return res.status(404).json({ message: "Suggestion not found" });

      // Authz: suggestion must belong to the user
      const userId = String((req as any).user?.id ?? (req as any).user?.userId ?? "");
      if (!userId || suggestion.userId !== userId) return res.status(403).json({ message: "Forbidden" });

      // Only allow applying "saved" suggestions
      if (suggestion.status !== "saved") return res.status(409).json({ message: "Suggestion is not in a saved state" });

      if (!suggestion.applyPayload) return res.status(409).json({ message: "Suggestion has no apply payload" });

      // Deep equality check: client must send EXACT stored payload (no mutation-in-flight)
      const stored = stableStringify(suggestion.applyPayload);
      const incoming = stableStringify(payload);
      if (stored !== incoming) return res.status(409).json({ message: "Payload mismatch" });

      // Record applied
      const { appliedAt } = await markSuggestionApplied({ id: suggestionId, userId, payload });

      // Optional: insert event row
      if (insertApplyEvent) {
        await insertApplyEvent({ suggestionId, userId, payload }).catch(() => undefined);
      }

      // Best-effort audit emit
      await emitApplyAudit({
        event: "gigstercoach.apply",
        suggestionId,
        userId,
        target: payload.target,
        action: payload.action,
        createdAt: appliedAt,
      });

      return res.json({ ok: true, suggestionId, appliedAt, payload });
    }
  );
}
