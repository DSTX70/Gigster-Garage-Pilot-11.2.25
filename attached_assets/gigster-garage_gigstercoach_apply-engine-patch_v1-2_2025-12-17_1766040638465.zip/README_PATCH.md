# GigsterCoach Apply Engine (v1.2) — Patch Kit

Canonical filename:
- gigster-garage_gigstercoach_apply-engine-patch_v1-2_2025-12-17.zip

## What this adds

- **shared/contracts/applyEngine.ts**: Typed `ApplyPayload` + allowed targets/actions.
- **Server helpers**: whitelist + payload validation + stable stringify + best-effort audit emitter.
- **Server route**: `POST /api/gigstercoach/suggestions/:id/apply`
  - validates payload shape
  - verifies suggestion ownership + saved state
  - enforces **deep equality** with stored payload
  - records applied + emits audit (best-effort)
- **Client helpers**: applyToString/applyToDraft + replace-confirm rule.
- **UI helper component**: `SuggestionApplyButton` (optional, integration-friendly)

## Integration steps (minimal)

### 1) Add shared contract
Copy:
- `shared/contracts/applyEngine.ts`

Then update any suggestion types to store `applyPayload: ApplyPayload`.

### 2) Database migration (if you store suggestions in SQL)
Run:
- `server/scripts/migrate_add_apply_engine_v1_2.sql`

If your suggestions table already has a JSON column for structured fields/payload:
- You can skip adding `apply_payload` and instead map your existing column to `applyPayload` in `getSuggestionById`.

### 3) Wire server route into routes.ts
Add:
- `server/routes/gigstercoachApplyEngine.ts`
- `server/lib/applyEngine/*`

In your main `server/routes.ts` (or router registration point), call:

```ts
import { registerGigstercoachApplyEngine } from "./routes/gigstercoachApplyEngine";

// Provide your existing middlewares + db hooks:
registerGigstercoachApplyEngine(app, {
  requireAuth,
  requirePlan,
  getSuggestionById: async (id) => {
    // TODO: implement using your db layer
  },
  markSuggestionApplied: async ({ id, userId, payload }) => {
    // TODO: update suggestion status -> 'applied', set applied_at/by, optionally store applied payload
    return { appliedAt: new Date().toISOString() };
  },
  insertApplyEvent: async ({ suggestionId, userId, payload }) => {
    // TODO: optional insert into gigstercoach_apply_events
  }
});
```

### 4) Update Suggestions records to include applyPayload
Wherever you save suggestions (v1.1 suggestions inbox), ensure saved rows include:

- `applyPayload: ApplyPayload`
- `status: 'saved'`

### 5) Client apply on explicit click (no autonomous edits)
Add:
- `client/src/lib/applyEngine.ts`

Then, in your suggestion card UI, when user clicks **Apply**:
1) `POST /api/gigstercoach/suggestions/:id/apply` with `{ payload }`
2) If OK, mutate the local draft with `applyToDraft(draft, payload)`.

Optional:
- Use `client/src/components/gigstercoach/SuggestionApplyButton.tsx` as a drop-in.

## Definition of Done checklist (v1.2)

- [ ] `shared/contracts/applyEngine.ts` exists and is used in both client and server builds
- [ ] Suggestions store a typed `applyPayload` per suggestion
- [ ] Server `POST /api/gigstercoach/suggestions/:id/apply` exists + enforces:
  - [ ] auth + plan
  - [ ] ownership
  - [ ] status saved only
  - [ ] deep equality vs stored payload
  - [ ] whitelist target/action
  - [ ] best-effort audit emit
- [ ] Client does NOT mutate drafts unless the user clicks Apply
- [ ] Replace operations require explicit confirm (UI)
