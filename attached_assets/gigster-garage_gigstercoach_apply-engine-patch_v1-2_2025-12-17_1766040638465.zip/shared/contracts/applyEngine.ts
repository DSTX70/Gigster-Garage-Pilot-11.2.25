/**
 * GigsterCoach Apply Engine — shared contract
 * v1.2 (2025-12-17)
 *
 * Contract-first: clients and servers MUST import from here.
 */

export const APPLY_ENGINE_VERSION = 1 as const;

export const APPLY_TARGETS = [
  "invoice.terms",
  "proposal.terms",
  "message.body",
] as const;

export type ApplyTarget = (typeof APPLY_TARGETS)[number];

export const APPLY_ACTIONS = ["append", "prepend", "replace"] as const;
export type ApplyAction = (typeof APPLY_ACTIONS)[number];

export type ApplyPayload = {
  /** Contract version for safe evolution */
  v: typeof APPLY_ENGINE_VERSION;
  /** Only whitelisted targets are allowed */
  target: ApplyTarget;
  /** How to apply the value */
  action: ApplyAction;
  /** Text to apply (plain text) */
  value: string;

  /**
   * Optional: additional context for auditing/debugging (non-authoritative)
   * Server must ignore unknown fields.
   */
  meta?: {
    source?: "gigstercoach_suggestion" | "manual";
    suggestionId?: string;
    createdAt?: string; // ISO
  };
};

export type ApplyRequestBody = {
  payload: ApplyPayload;
};

export type ApplyResponseBody = {
  ok: true;
  suggestionId: string;
  appliedAt: string; // ISO
  payload: ApplyPayload;
};
