import { describe, it, expect, vi, beforeEach } from "vitest";
import { createClient } from "../src/index";
describe("Importer", () => {
  beforeEach(() => {
    // @ts-ignore
    global.fetch = vi.fn(async (url: string, init: any) => {
      if (url.includes("/api/import/sessions/abc/commit") && init?.method === "POST") {
        return new Response(JSON.stringify({ accepted: 42 }), { status: 202, headers: { "content-type": "application/json" } });
      }
      return new Response("Not Found", { status: 404 });
    });
  });
  it("commit staged rows", async () => {
    const client = createClient({ baseUrl: "http://localhost:8000" });
    const res = await client.postApiImportSessionsBySessionIdCommit({ params: { sessionId: "abc" } });
    expect(res.accepted).toBe(42);
  });
});