# Automation Add-ons

This folder contains drop-in GitHub workflows and config:

1) **release-please** (`.github/workflows/release-please.yml`)
   - Creates/merges a Release PR from conventional commits
   - Writes `CHANGELOG.md`
   - Bumps version in package.json
   - When the PR is merged, it tags `vX.Y.Z` automatically
   - Your existing `release.yml` then builds/tests/publishes to npm

2) **docs-pages** (`.github/workflows/docs-pages.yml`)
   - On GitHub Release (or manual), builds Typedoc (`npm run docs`)
   - Publishes the `/docs` folder to GitHub Pages

## Setup
- Enable Pages: Settings → Pages → Source = GitHub Actions
- Ensure `typedoc` is in devDependencies and `npm run docs` is configured
- Use conventional commits (feat, fix, docs, chore, etc.) for best changelogs
