import { describe, it, expect, vi, beforeEach } from "vitest";
import { createClient } from "../src/index";
describe("Packsmith", () => {
  beforeEach(() => {
    // @ts-ignore
    global.fetch = vi.fn(async (url: string, init: any) => {
      if (url.includes("/api/packs/123/blueprint") && init?.method === "POST") {
        return new Response(JSON.stringify({ packId: "123" }), { status: 200, headers: { "content-type": "application/json" } });
      }
      return new Response("Not Found", { status: 404 });
    });
  });
  it("blueprint", async () => {
    const client = createClient({ baseUrl: "http://localhost:8000" });
    const res = await client.postApiPacksByPackIdBlueprint({ params: { packId: "123" } });
    expect(res.packId).toBe("123");
  });
});