import { describe, it, expect, vi, beforeEach } from "vitest";
import { createClient } from "../src/index";
describe("iCadence", () => {
  beforeEach(() => {
    // @ts-ignore
    global.fetch = vi.fn(async (url: string, init: any) => {
      if (url.includes("/api/icadence/channels/chan-1/test-post") && init?.method === "POST") {
        return new Response(JSON.stringify({ ok: true }), { status: 200, headers: { "content-type": "application/json" } });
      }
      return new Response("Not Found", { status: 404 });
    });
  });
  it("test post", async () => {
    const client = createClient({ baseUrl: "http://localhost:8000" });
    const res = await client.postApiIcadenceChannelsByChannelIdTestPost({ params: { channelId: "chan-1" }, body: { message: "hello" } });
    expect(res.ok).toBe(true);
  });
});