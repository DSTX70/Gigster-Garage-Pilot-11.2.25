// see previous cell: full SwitchboardDashboard.tsx; copy into your project
