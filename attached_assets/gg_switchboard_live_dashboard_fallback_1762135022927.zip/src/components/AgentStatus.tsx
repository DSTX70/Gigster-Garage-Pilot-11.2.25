import { useEffect, useState } from 'react'

export default function AgentStatus(){
  const [data, setData] = useState<any>(null)
  const [err, setErr] = useState<string | null>(null)

  useEffect(() => {
    fetch('/visibility_flags.json').then(r => r.json()).then(setData).catch(e => setErr(String(e)))
  }, [])

  if (err) return <div className="text-red-600 text-sm">Error: {err}</div>
  if (!data) return <div className="text-sm text-neutral-600">Run <code>npm run switchboard</code> to generate <code>public/visibility_flags.json</code>, then refresh.</div>

  const color = (kpiOK:boolean, dateOK:boolean) => kpiOK ? 'bg-green-500' : (dateOK ? 'bg-amber-400' : 'bg-red-500')
  const entries = Object.entries(data.by_agent || {}) as [string, any][]

  return (
    <div className="rounded-2xl shadow p-5 bg-white border border-neutral-200">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-xl font-heading">Agent Status — KPIs vs. Thresholds</h2>
        <a href="/visibility_flags.json" className="text-xs underline">view JSON</a>
      </div>
      <div className="space-y-3">
        {entries.map(([id, v]) => (
          <div key={id} className="border rounded-xl p-3 flex items-start gap-3">
            <div className={`w-3 h-3 rounded-full mt-1 ${color(v.kpiOK, v.dateOK)}`} />
            <div className="flex-1">
              <div className="text-sm font-semibold">{id}</div>
              <div className="text-xs text-neutral-600">
                expose_to_users: <b>{String(v.expose_to_users)}</b> · kpiOK: <b>{String(v.kpiOK)}</b> · dateOK: <b>{String(v.dateOK)}</b>
              </div>
              {v.metrics && <pre className="bg-neutral-50 p-2 rounded mt-2 text-[11px] overflow-auto">{JSON.stringify(v.metrics, null, 2)}</pre>}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
