// see previous cell: kpis.ts content omitted for brevity in this fallback step
