// scripts/switchboard.mjs
import fs from 'node:fs'
const flagsSrc = process.env.SWITCHBOARD_FLAGS_SRC || 'public/gg_visibility_flags_patch.json'
const kpiSrc = process.env.SWITCHBOARD_KPI_SRC || 'public/agent_kpis.json'
const outPath = process.env.SWITCHBOARD_OUT || 'public/visibility_flags.json'
const dryRun = process.env.SWITCHBOARD_DRY_RUN === 'true'

const patches = JSON.parse(fs.readFileSync(flagsSrc, 'utf-8'))
const kpis = JSON.parse(fs.readFileSync(kpiSrc, 'utf-8'))

function meetsKPIs(m){
  if (!m) return false
  const ok1 = (m.on_time_milestone_rate ?? 0) >= 0.95
  const ok2 = (m.gate_escape_rate ?? 1) <= 0.01
  const ok3 = (m.incident_count_30d ?? 1) === 0
  return ok1 && ok2 && ok3
}
function datePassed(iso){
  if (!iso) return false
  return new Date() >= new Date(iso)
}

const out = { by_agent: {}, generated_at: new Date().toISOString() }
for (const p of patches.visibility_patches){
  const id = p.id
  const vis = { ...p.visibility }
  const m = kpis[id]
  const kpiOK = meetsKPIs(m)
  const dateOK = datePassed(p.visibility?.graduation_plan?.flip_on)
  const shouldExpose = kpiOK || dateOK
  vis.expose_to_users = shouldExpose ? true : vis.expose_to_users
  out.by_agent[id] = { ...vis, kpiOK, dateOK, metrics: m }
}

if (dryRun){
  console.log('[Switchboard] DRY RUN:\n'+JSON.stringify(out,null,2))
} else {
  fs.writeFileSync(outPath, JSON.stringify(out, null, 2))
  console.log('[Switchboard] wrote', outPath)
}
